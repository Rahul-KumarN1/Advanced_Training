package com.sl.at;

import java.util.Scanner;

public class FirstRepeatingElement {
	
	 public static void main(String[] args)  
	    { 
	        Scanner sr = new Scanner(System.in);
	        System.out.print("eneter the size of array: ");
	        int n = sr.nextInt();
	        System.out.print("eneter elements of array: ");
	        int arr[] = new int[n];
	        for(int i=0;i<n;i++)
	        {
	            arr[i] = sr.nextInt();
	        }
	        int count=0;
	        for(int i=0;i<n;i++) 
	        for(int j=i+1;j<n;j++) 
	            if(arr[i]==arr[j])
	              {
	                System.out.println("first repeating element is:"+arr[i]);
	                count=1;
	                break;
	              }
	        if(count==0)
	        System.out.println("No repeating integer found");
	    }

}
