package com.sl.at;

import java.util.Scanner;
import java.util.Timer;

public class MinPlatform {
	
	static int numberPlatforms(int n,int arr[],int dep[])
	 {
	    int result=1; 
	    for(int i=0;i<=n-1;i++)
	    {
	        int number=1;
	        for(int j=i+1;j<=n-1;j++)
	        {
	            if((arr[i]>=arr[j] && arr[i]<=dep[j]) ||
	           (arr[j]>=arr[i] && arr[j]<=dep[i]))
	           {
	            	number++;
	           }
	        }
	        result=Math.max(result,number);
	    }
	    return result;
	 }
	 
	 
	public static void main (String[] args) {
			
			int[] arr ={900,945,955,1100,1500,1800};
			int[] dep={920,1200,1130,1150,1900,2000};
			int n=arr.length;
			int totalCount=numberPlatforms(n,arr,dep);
			System.out.println("Minimum number of Platforms required "+totalCount);
		}

}
