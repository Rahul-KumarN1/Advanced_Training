package com.sl.at;

public class FindingDuplicates {
	
	 public static void main(String[] args) {  
         
	          
	        int [] arr = new int [] {1,2,2,3,4,4,5,6,6,7,8,9,9};   
	         
	        int [] fr = new int [arr.length];  
	        int a = -1;  
	        
	        for(int i = 0; i < arr.length; i++){  
	            int freq = 1;  
	            for(int j = i+1; j < arr.length; j++){  
	                if(arr[i] == arr[j]){  
	                    freq++;   
	                    fr[j] = a;  
	                }  
	            }  
	            if(fr[i] != a)  
	                fr[i] = freq;  
	        }  
	        
	         
	        for(int i = 0; i < fr.length; i++){  
	            if(fr[i] != a)  
	                System.out.println("    " + arr[i] + "    occurs    " + fr[i]);  
	        }  
	          
	    }  
	} 