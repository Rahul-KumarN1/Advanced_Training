package com.sl.at;

import java.util.*;

public class CoinChange {
	public static void main(String[] args) {

	    int V = 49;
	    ArrayList < Integer > ans = new ArrayList < > ();
	    int currency[] = {1, 2, 5, 10, 20, 50, 100, 500, 1000};
	    int n = currency.length;
	    for (int i = n - 1; i >= 0; i--) {
	      while (V >= currency[i]) {
	        V -= currency[i];
	        ans.add(currency[i]);
	      }
	    }
	    System.out.println("The minimum number of currency required is "+ans.size());
	    System.out.println("The coins/notes are ");
	    for (int i = 0; i < ans.size(); i++) {
	      System.out.print(" " + ans.get(i));
	    }

	  }

}
