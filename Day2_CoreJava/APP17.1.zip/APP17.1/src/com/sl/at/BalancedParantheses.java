package com.sl.at;

import java.util.Scanner;
import java.util.Stack;

public class BalancedParantheses {
	
	public static boolean expBalanced(String exp)
    {
        
        if (exp == null || exp.length() % 2 == 1) {
            return false;
        }
 
        
        Stack<Character> stack = new Stack<>();
        
        for (char expcheck: exp.toCharArray())
        {
            if (expcheck == '(' || expcheck == '{' || expcheck == '[') {
                stack.push(expcheck);
            }
 
            if (expcheck == ')' || expcheck == '}' || expcheck == ']')
            {
                
                if (stack.empty()) {
                    return false;
                }
 
                
                Character top = stack.pop();
 
                
                if ((top == '(' && expcheck != ')') || (top == '{' && expcheck != '}')
                        || (top == '[' && expcheck != ']')) {
                    return false;
                }
            }
        }
        return stack.empty();
    }
 
    public static void main(String[] args)
    {
    	System.out.println("Enter the expression");
        Scanner sc=new Scanner(System.in);
        String exp=sc.next();
    	
 
        if (expBalanced(exp)) {
            System.out.println("The expression is balanced");
        }
        else {
            System.out.println("The expression is not balanced");
        }
    }

}
