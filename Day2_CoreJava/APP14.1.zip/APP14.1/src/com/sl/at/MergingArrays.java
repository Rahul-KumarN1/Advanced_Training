package com.sl.at;

import java.util.Arrays;
import java.util.Scanner;

public class MergingArrays {
	
	public static void main(String[] args){
		Scanner sr = new Scanner(System.in);
        System.out.print("eneter the size of array: ");
        int n = sr.nextInt();
        System.out.print("eneter elements of array: ");
        int arr1[] = new int[n];
        for(int i=0;i<n;i++)
        {
            arr1[i] = sr.nextInt();
        }
        Scanner sr1 = new Scanner(System.in);
        System.out.print("eneter the size of array: ");
        int m = sr1.nextInt();
        System.out.print("eneter elements of array: ");
        int arr2[] = new int[n];
        for(int i=0;i<n;i++)
        {
            arr2[i] = sr1.nextInt();
        }
	      
	      
	      int count1 = arr1.length;
	      int count2 = arr2.length;
	      int [] resultArr = new int[count1 + count2];
	      int i=0, j=0, k=0;
	      while (i < arr1.length) {
	         resultArr[k] = arr1[i];
	         i++;
	         k++;
	      }
	      while (j < arr2.length) {
	         resultArr[k] = arr2[j];
	         j++;
	         k++;
	      }
	      Arrays.sort(resultArr);
	      System.out.println("Sorted Merged Array = "+Arrays.toString(resultArr));
	   }

}
