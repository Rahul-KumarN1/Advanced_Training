package com.sl.at;

import java.util.Scanner;

public class Rectangle_Pgm2 {
	double length;
	double width;
	double area;
	double perimeter;
	
	public Rectangle_Pgm2() {
		length=1;
		width=1;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}
	public void input() {
		System.out.println("Enter length");
		Scanner l1=new Scanner(System.in);
		length = l1.nextInt();
		System.out.println("Enter length");
		Scanner b1=new Scanner(System.in);
		width = b1.nextInt();
	}
	public void calculateArea() {
		area=length*width;
	}
	public void calculatePerimter() {
		perimeter=2*(length+width);
	}
	
	public void display() {
		if(length>0 && length<20) {
			if(width>0 && length<20) {
				System.out.println("Area of the rectangle is:"+ area );
				System.out.println("Perimeter of the rectangle is:"+ perimeter );
			}
		}
		 
	}
	
public static void main(String[] args) {
		
	Rectangle_Pgm2 rect1=new Rectangle_Pgm2();
		rect1.input();
		rect1.calculateArea();
		rect1.display();
		Rectangle_Pgm2 rect2=new Rectangle_Pgm2();
		rect2.input();
		rect2.calculateArea();
		rect2.display();
		Rectangle_Pgm2 rect3=new Rectangle_Pgm2();
		rect3.input();
		rect3.calculateArea();
		rect3.display();
		Rectangle_Pgm2 rect4=new Rectangle_Pgm2();
		rect4.input();
		rect4.calculateArea();
		rect4.display();
		Rectangle_Pgm2 rect5=new Rectangle_Pgm2();
		rect5.input();
		rect5.calculateArea();
		rect5.display();
	}
}
