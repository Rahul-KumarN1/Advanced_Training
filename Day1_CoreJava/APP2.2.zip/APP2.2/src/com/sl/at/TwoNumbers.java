package com.sl.at;

import java.util.*;

public class TwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int firstTerm;
		int secondTerm;
		Scanner sc1=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		firstTerm=sc1.nextInt();
		secondTerm=sc2.nextInt();
		
		for(int i=0;i<13;i++) {
			System.out.print(firstTerm + ","+secondTerm+  ", ");
			int nextTerm = firstTerm + secondTerm;
			System.out.print(nextTerm);
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;
			
		}
		
	}

}
