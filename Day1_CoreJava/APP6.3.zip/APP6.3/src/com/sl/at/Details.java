package com.sl.at;

import java.util.*;

public class Details {
	public static Employee[] v;
	public static void main(String[] args) {
		LinkedList<Employee> v = addInput();
		display(v);
		}

	public static LinkedList<Employee> addInput() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void display(LinkedList<Employee> v2) {
		// TODO Auto-generated method stub
		
	}

	public static Collection<Employee> main1(String[] args) {
		Employee e1=new Employee (101,"Rahul", "Patna");
		Employee e2=new Employee (102,"Utkarsh", "Delhi");
		Employee e3=new Employee (103,"Pallav", "Bangalore");
		LinkedList<Employee> e=new LinkedList<Employee>();
		e.add(e1);
		e.add(e2);
		e.add(e3);
		return e;
	}
	public static void main11(String[] args) {
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}

}
