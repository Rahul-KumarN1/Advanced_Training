package com.sl.at;
import java.util.*;

public class Rectangle {
	int length;
	int breadth;
	int area;
	
	public Rectangle() {
		length=0;
		breadth=0;
	}
	public void input() {
		System.out.println("Enter length");
		Scanner l1=new Scanner(System.in);
		length = l1.nextInt();
		System.out.println("Enter length");
		Scanner b1=new Scanner(System.in);
		breadth = b1.nextInt();
		
	}
	public void calculateArea() {
		area=length*breadth;
	}
	public void display() {
		 System.out.println("Area of the rectangle is:"+ area );
	}
	
	public static void main(String[] args) {
		
		Rectangle rect1=new Rectangle();
		rect1.input();
		rect1.calculateArea();
		rect1.display();
		Rectangle rect2=new Rectangle();
		rect2.input();
		rect2.calculateArea();
		rect2.display();
		Rectangle rect3=new Rectangle();
		rect3.input();
		rect3.calculateArea();
		rect3.display();
		Rectangle rect4=new Rectangle();
		rect4.input();
		rect4.calculateArea();
		rect4.display();
		Rectangle rect5=new Rectangle();
		rect5.input();
		rect5.calculateArea();
		rect5.display();
	}

}
