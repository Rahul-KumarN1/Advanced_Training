package com.sl.at;

import java.util.*;

public class StudentList {
	 public static void main (String[] args) {
		 ArrayList<String> a1=new ArrayList<String>();
		 
	 Scanner sc= new Scanner(System.in);
	 System.out.println("Please enter the number of students ");
     int n = sc.nextInt();
	 
	for(int i=0;i<n;i++)
	{
		System.out.println("enter the student names:");
		 Scanner sc1= new Scanner(System.in);
		 String s=sc1.nextLine();
		 a1.add(s);
	}
	System.out.println("student list:" + a1);
	System.out.println("enter the name of the student to be searched:");
	Scanner sc2= new Scanner(System.in);
	for(String a:a1)
	{
			
		    String st=sc2.nextLine();
		    
		    
		    	
		    if(a1.contains(st)) 
		    	System.out.println("You searched for: "+ st);
		    
		    else
	            System.out.println("does not exist in the ArrayList");
			
			}
	 } 

}

