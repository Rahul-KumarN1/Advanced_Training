package com.sl.at;

import java.util.Scanner;

public class CheckPalindrome {
	
	public static void main(String args[]) {
		String str;
		char ch;
		System.out.println("Enter a string");
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		System.out.println(str.toUpperCase());
		 int n = str.length();
		 boolean result=true;
		 for (int i = 0; i < n / 2; i++)
	            if (str.charAt(i) != str.charAt(n - i - 1)) {
	            
	            result=false;
	}
		 System.out.print("Palindrome status:" +result);

}
}
