package com.sl.at;

public class Mainclass {
	
	
public void createBooks() {
	Book list[]=new Book[2];
	list[0]=new Book("Java Programming",350.50);
	list[1]=new Book("Let us C",200.00);
	for(int i=0;i<list.length;i++) {
		list[i].display();
		System.out.println("");
	}
}

public void showBooks() {
	createBooks();
}

public static void main(String[] args) {
	
	Mainclass c1=new Mainclass();
	c1.showBooks();
}

	

}

