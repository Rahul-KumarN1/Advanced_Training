package com.sl.at;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListEvenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list=new ArrayList<Integer>();
		Scanner limit=new Scanner(System.in);
		System.out.println("Select the number");
		int n=limit.nextInt();
		for(int i=0;i<n;i+=2) {
			list.add(i);
		}
		System.out.print(list);

	}

}
