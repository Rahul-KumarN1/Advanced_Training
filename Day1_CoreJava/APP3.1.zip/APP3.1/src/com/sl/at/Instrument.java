package com.sl.at;

public abstract class Instrument {
	public abstract void play();
}
