package com.sl.at;

public class IntArray {
	public static void main(String[] args) { 
		int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
		int min=arr[0];
		for(int i=0;i<14;i++) {
			arr[15]+=arr[i];
		}
		System.out.println(arr[15]);
		for(int i=0;i<15;i++) {
			arr[16]+=arr[i];
			
		}
		arr[16]=arr[16]/15;
		System.out.println(arr[16]);
		for(int i=0;i<16;i++) {
			
			if(arr[i]<min) {
				min=arr[i];
			}
		}
		
		System.out.println(arr[17]);
	}

}
